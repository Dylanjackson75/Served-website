document.addEventListener('DOMContentLoaded',()=>{
  console.log('SERVED base loaded');
});