SERVED — Production Package (v4.8b WHITE CONTRAST)

Contents
========
/index.html          — Homepage (white theme with black contrast, hero + carousel)
/assets/             — Images (hero.jpg, mock-compact.jpg)
/css/styles.css      — Styles (palette, spacing, responsive sizes)
/js/script.js        — Small behavior (smooth anchors)

What you can edit
-----------------
- Headlines, city list, and copy: edit in index.html
- Colors and spacing: edit css/styles.css (root variables at the top)
- Mailchimp form: in index.html, keep the action URL as provided by Mailchimp

Deploy
------
1) Netlify → your project → Deploys
2) Drag this ZIP onto "Browse to upload"
3) Wait for "Published" then open your domain

Notes
-----
- Hero text readability: controlled by .hero-overlay and text-shadow in CSS
- Carousel image sizing: .mock-card img max-width set to 500px
- Cities: fixed 5×3 grid; adjust in .grid-5 if you need fewer/more
- Waitlist segmentation: select[name="SEGMENT"] has Client / Hospitality Pro
